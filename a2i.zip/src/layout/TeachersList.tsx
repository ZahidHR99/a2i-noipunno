export default function TeachersList() {
  return (
    <div>
    <h1>List of Teachers</h1>
    {/* <ul>
      {teachers.map((teacher) => (
        <li key={teacher.id}>
          <h2>{teacher.name_en}</h2>
          <p>Email: {teacher.email}</p>
          <p>Mobile No: {teacher.mobile_no}</p>
         
        </li>
      ))}
    </ul> */}
  </div>
  )
}
